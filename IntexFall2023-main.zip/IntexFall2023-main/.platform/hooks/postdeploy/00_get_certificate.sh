#!/usr/bin/env bash
sudo certbot -n -d intexfall2023.us-east-1.elasticbeanstalk.com --nginx --agree-tos --email jblosil1@byu.edu
sudo certbot -n -d intexfall2023.is404.net --nginx --agree-tos --email jblosil1@byu.edu
